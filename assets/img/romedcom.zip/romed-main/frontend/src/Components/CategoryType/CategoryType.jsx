import Header from "./../../UI/Header/Header"

const CategoryType = (props) => {
  return (
    <>
      <Header />

      hehe pina cind asa
    </>
  )
}
export default CategoryType