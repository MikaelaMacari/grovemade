// import React from 'react';
// import './Categories.css';
// import Navbar from '../Header/Header';
// import Footer from '../Footer/Footer';
// import {Container, Card, Row, Col, Button, CardGroup} from 'react-bootstrap';

// import image1 from '../../assets/images/categories_1.png';
// import image2 from '../../assets/images/categories_2.png';


// const Category = () => {

//   return (
// <>
//   <Navbar />    
//   <Container fluid className="text-center  pt-3 pb-3 mt-4">
//     <h1 className='fs-1 text-uppercase text-center'>Dispozitive de Diagnostic</h1>
//     <div className="underline mx-auto mb-4"></div>
//   </Container>

//   <Footer />
// </>
//   );
// }

// export default Category;

